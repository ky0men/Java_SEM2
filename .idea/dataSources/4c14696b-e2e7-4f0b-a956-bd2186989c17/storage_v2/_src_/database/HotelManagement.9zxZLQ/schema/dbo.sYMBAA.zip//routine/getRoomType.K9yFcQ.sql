CREATE PROC getRoomType @roomName VARCHAR(15) AS
    SELECT RT.roomTypeName FROM Room R JOIN RoomType RT ON R.roomTypeID = RT.roomTypeID WHERE R.roomName = @roomName
go

