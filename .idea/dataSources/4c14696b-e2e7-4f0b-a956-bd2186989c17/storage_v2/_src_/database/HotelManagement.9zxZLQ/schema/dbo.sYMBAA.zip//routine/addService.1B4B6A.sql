--DROP PROC updateService
--Procedure add service
CREATE PROC addService  @serviceName varchar(100), @serviceType varchar(100), @price int, @unit varchar(20) AS
	INSERT INTO Service VALUES (@serviceName, @serviceType, @price, @unit, '')
go

