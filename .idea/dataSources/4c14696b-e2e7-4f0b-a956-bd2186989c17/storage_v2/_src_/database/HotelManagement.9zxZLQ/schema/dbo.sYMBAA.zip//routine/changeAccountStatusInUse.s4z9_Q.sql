CREATE PROC changeAccountStatusInUse @username VARCHAR(15) AS
    UPDATE Account SET accountStatus = '1' WHERE username = @username
go

