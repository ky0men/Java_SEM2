-- Procedure check and get customer name from customer Identiry number
CREATE PROC getCusNameFromIDNumber @idNum VARCHAR(20) AS
    SELECT CUS.cusName FROM Customer CUS WHERE CUS.cusIdentityNumber = @idNum
go

