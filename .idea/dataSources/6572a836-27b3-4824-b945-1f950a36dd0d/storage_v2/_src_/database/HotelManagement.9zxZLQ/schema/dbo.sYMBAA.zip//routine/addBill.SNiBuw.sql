CREATE PROC addBill @employeeID INT, @cusName NVARCHAR(200), @date DATE, @month INT, @year INT, @revenue MONEY AS
    INSERT INTO bill VALUES (@employeeID, @cusName, @date, @month, @year, @revenue)
go

