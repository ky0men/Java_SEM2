
--Procedure add service
CREATE PROC addService  @serviceName varchar(100), @serviceType varchar(100), @price int, @unit varchar(20), @volume int AS
	INSERT INTO Service VALUES (@serviceName, @serviceType, @price, @unit, @volume)
go

