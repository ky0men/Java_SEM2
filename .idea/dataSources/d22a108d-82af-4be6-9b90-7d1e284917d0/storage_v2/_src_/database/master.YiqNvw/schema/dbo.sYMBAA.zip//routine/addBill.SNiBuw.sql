
--PROCEDURE add Bill
CREATE PROC addBill @employeeID INT, @cusName NVARCHAR(200), @date DATE, @month INT, @year INT, @revenue MONEY AS
    INSERT INTO bill VALUES (@employeeID, @cusName, @date, @month, @year, @revenue)

SELECT Room.roomName FROM Room       

  SELECT S.ServiceName, S.Price, SUM(US.usedServiceQty) AS N'Quantity', S.Unit 
    FROM usedServices US JOIN Service S ON US.usedServiceID = S.ID JOIN Checkin CI ON CI.checkinID = US.checkinID 
    WHERE CI.roomNumber = '" + roomNumber + "' AND CI.wasPayment = '0' GROUP BY S.ServiceName, S.Price, S.Unit

 SELECT B.printMonth, SUM(B.revenue) AS 'Sum' FROM bill B WHERE B.printMonth = '2' GROUP By B.printMonth

 select * from Room
go

