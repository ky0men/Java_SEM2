
--PROCEDURE add Bill
CREATE PROC addBill @employeeID INT, @cusID VARCHAR(20), @date DATE, @month INT, @year INT, @revenue MONEY AS
    INSERT INTO bill VALUES (@employeeID, @cusID, @date, @month, @year, @revenue)


go

