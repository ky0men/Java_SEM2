
--Procedure check account
CREATE PROC checkLogin @username VARCHAR(15), @pass VARCHAR(60) AS 
    SELECT * FROM Account AD JOIN EmployeeInformation EM ON AD.id = EM.userID
    WHERE AD.username = @username AND AD.passwordHash = HASHBYTES('SHA2_512', @pass) AND EM.deleted = '0'
go

